module.exports = {
  id: 'ID',
  name: 'Nome',
  email: 'E-mail',
  password_hash: 'Senha',
};

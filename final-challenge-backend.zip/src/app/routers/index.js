import category from './category';
import reason from './reason';
import product from './product';
import swagger from './swagger';

export default [category, reason, product, swagger];
